# -*- coding: utf-8 -*-

'''
    Online Stream Addon for Kodi
    Copyright (C) 2017 aky01
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys,urllib,re,urlparse,xbmcaddon,xbmcgui,xbmc,os

from resources.lib import client
from resources.lib import cache
from resources.lib import directory
from resources.lib import favorite

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__addonicon__ = __addon__.getAddonInfo('icon')
__lang__ = xbmcaddon.Addon().getLocalizedString
__dialog__ = xbmcgui.Dialog()
onlinestream_url = 'https://onlinestream.live'
headers = {'User-Agent': 'Online Stream for Kodi/%s' % __addon__.getAddonInfo('version')}


class indexer:
    def __init__(self):
        self.list = []


    def resolve(self, url, image, title, mediatype, multi_res):
        if mediatype == 'Music':
            try: url = client.request(url, geturl=True, timeout='3')
            except: pass

        pattern = 'KD86eW91dHViZVwuY29tXC9cUyooPzooPzpcL2UoPzptYmVkKSk/XC98d2F0Y2hcPyg/OlxTKj8mP3ZcPSkpfHlvdXR1XC5iZVwvKShbYS16QS1aMC05Xy1dezYsMTF9KQ=='.decode('base64')
        yt_link = re.search(pattern, url)
        if yt_link:
            url = 'plugin://plugin.video.youtube/play/?video_id=%s' % yt_link.group(1)
    
        if not yt_link and multi_res == True:
            r = client.request(url)
            query = re.search("(https?.+?m3u8)", r)
            if query:
                query = query.group(1)
                try:
                    r = client.request(query)
                    sources = re.findall('RESOLUTION\s*=\s*(\d+x\d+).+\n\s*(.*\.m3u8)', r)
                    if len(sources) > 1:
                        q = __dialog__.select(__lang__(32013).encode('utf-8'), [i[0] for i in sources])
                        if q == -1: return
                    else: q = 0
                    url = query.rsplit('/', 1)[0] + '/' + sources[q][1]
                except:
                    url = query
    
        item = xbmcgui.ListItem(path=url)
        item.setArt({'icon': image, 'thumb': image})
        item.setInfo(type=mediatype, infoLabels={'Title': title})
        xbmc.Player().play(url, item)


    def favorites(self):
        try:
            fav_list = favorite.getFavorites()
            if fav_list == []: raise Exception()
            
            for id, title, type, image in fav_list:
                id = id.encode('utf-8')
                title = title.encode('utf-8')
                type = type.encode('utf-8')
    
                cm = [{'title': __lang__(32009).encode('utf-8'), 'query': {'action': '%s_track_list' % type, 'station_id': id}},
                    {'title': __lang__(32018).encode('utf-8'), 'query': {'action': 'favorite_delete', 'station_id': id}}]
                label = __lang__(32014).encode('utf-8') if type == 'tv' else __lang__(32015).encode('utf-8')
                self.list.append({'action': '%s_stream_list' % type, 'label': '%s  (%s)' % (title, label), 'image': image, 'station_id': id, 'cm': cm}) 
    
            directory.add(self.list, content='addons', infotype='', isFolder=False)
        except:
            __dialog__.notification(__addonname__, __lang__(32019).encode('utf-8'), __addonicon__, 3000, sound=False)
            return

    def get_stations(self, action):
        stations = cache.get(self.get_xml, 1, action)
        if stations == None or stations == []:
            cache.clear()
            __dialog__.notification(__addonname__, __lang__(32011).encode('utf-8'), __addonicon__, 3000, sound=False)
            return

        if action == 'tv':
            tv_seq = cache.get(self.get_tv_seq, 1)

            filter = []
            for i in tv_seq:
                for x in stations:
                    if i == client.parseDOM(x, 'station_id')[0]:
                        filter.append(x)
    
            filter += [i for i in stations if not i in filter]
            stations = [i for i in filter if not all('' == s.strip() for s in client.parseDOM(i, 'stream_url')) or not all('' == x.strip() for x in client.parseDOM(i, 'hls_url'))]

        return stations


    def station_list(self, action, search_text=None):
        stations = self.get_stations(action)
        fav_ids = favorite.getFavorites(id=True)

        for item in stations:
            try:
                title = client.parseDOM(item, 'title')[0]
                title = client.replaceHTMLCodes(title).replace("&apos;", "'").encode('utf-8')

                station_id = client.parseDOM(item, 'station_id')[0].encode('utf-8')

                logo = client.parseDOM(item, 'logo')[0].encode('utf-8')
                if logo == None or logo.strip() == '': logo = os.path.join(__addon__.getAddonInfo('path'), 'resources', 'media', '%s.png' % action)
                
                if action == 'radio':
                    description = client.parseDOM(item, 'description')[0]
                    description = client.replaceHTMLCodes(description).replace("&apos;", "'").encode('utf-8')
    
                    listeners = client.parseDOM(item, 'listeners')[0].encode('utf-8')
                    listeners = listeners if listeners.isdigit() and int(listeners) >= 0 else ''
                    
                    listeners_peak = client.parseDOM(item, 'listeners_peak')[0].encode('utf-8')
                    
                    broadcast = client.parseDOM(item, 'broadcast')[0].encode('utf-8')
                    broadcast = 'DAB+/FM' if broadcast == '1' else ''
                    
                    station_title = '[COLOR white][B]%s[/B][/COLOR]' % title
                    if not broadcast == '': station_title += '  [COLOR FF008000]%s[/COLOR]' % broadcast
                    if not listeners == '': station_title += '  [%s/%s]' % (listeners, listeners_peak)
                else: 
                    station_title = title
                
                cm = [{'title': __lang__(32009).encode('utf-8'), 'query': {'action': '%s_track_list' % action, 'station_id': station_id}}]
                if not station_id in fav_ids:
                    cm.append({'title': __lang__(32017).encode('utf-8'), 'query': {'action': 'favorite_add', 'station_id': station_id, 'title': title, 'type': action, 'image': logo}})

                self.list.append({'title': title, 'label': station_title, 'image': logo, 'station_id': station_id, 'cm': cm})

            except:
                pass
        
        
        if not search_text == None:
            self.list = [i for i in self.list if search_text.lower() in i['title'].lower()]
            if self.list == []:
                __dialog__.notification(__addonname__, __lang__(32012).encode('utf-8'), __addonicon__, 3000, sound=False)
                return

        if self.list == []: return
        for i in self.list: i.update({'action': '%s_stream_list' % action})
        
        infotype = 'Music' if action == 'radio' else 'Video'
        directory.add(self.list, content='addons', infotype=infotype, isFolder=False)


    def stream_list(self, station_id, action, image='', track_list=False):
        stations = self.get_stations(action)

        station = [i for i in stations if station_id == client.parseDOM(i, 'station_id')[0].encode('utf-8')]

        station_title = client.parseDOM(station[0], 'title')[0].encode('utf-8')
        channels = client.parseDOM(station, 'channel')

        for item in channels:
            try:
                stream_url = client.parseDOM(item, 'stream_url')[0].encode('utf-8')
                hls_url = client.parseDOM(item, 'hls_url')[0].encode('utf-8')
                if stream_url.strip() == '' and hls_url.strip() == '': continue
                
                channel_id = client.parseDOM(item, 'channel_id')[0].encode('utf-8')
                
                description = client.parseDOM(item, 'description')[0]
                description = client.replaceHTMLCodes(description).replace("&apos;", "'").encode('utf-8')
                
                format = client.parseDOM(item, 'format')[0].encode('utf-8')
                
                channel_title = client.parseDOM(item, 'title')[0].encode('utf-8')
                
                listeners = client.parseDOM(item, 'listeners')[0].encode('utf-8')
                listeners = listeners if listeners.isdigit() and int(listeners) >= 0 else '?'
                
                listeners_peak = client.parseDOM(item, 'listeners_peak')[0].encode('utf-8')
                
                bitrate = client.parseDOM(item, 'bitrate')[0].encode('utf-8')
                
                resolution = client.parseDOM(item, 'video_resolution')[0]

                if action == 'radio':
                    mediatype = 'Music' if not format.strip().lower() in ['flv', 'hls'] else 'Video'
                    title = '%s: %s [%s/%s] [%s, %s kbps]' % (channel_id, channel_title, listeners, listeners_peak, format, bitrate)
                    title = re.sub('\[\?\/.*\]\s', '', title)
                    if re.search(',\s+\D', title):
                        title = re.sub('\s*kbps', '', title)
                    litle = title.replace('[?, ', '[').replace('[, ', '[')
                    title = re.sub(',\s*\?', '', title)
                    title = re.sub('\[\s*\??\s*\]', '', title)

                else:
                    mediatype = 'Video'
                    title = 'Stream %s - %s' % (channel_id, description) if not description == '' else 'Stream %s' % channel_id

                self.list.append({'station_title': station_title, 'title': title, 'stream_url': stream_url, 'hls_url': hls_url, 'video_resolution': resolution, 'mediatype': mediatype})
            except:
                pass

        if self.list == []: return

        if not track_list == False:
            return self.list

        ch_list = [i['title'] for i in self.list]

        if len(self.list) > 1:
            q = __dialog__.select(__lang__(32008).encode('utf-8'), ch_list)
            if q == -1: return
        else: q = 0

        mediatype = self.list[q]['mediatype']
        url = self.list[q]['hls_url'] if mediatype == 'Video' and self.list[q]['hls_url'].strip() != '' else self.list[q]['stream_url']
        multi_res = True if u'T\xf6bbf\xe9le' in self.list[q]['video_resolution'] else False
        title = self.list[q]['station_title']
        self.resolve(url, image, title=title, mediatype=mediatype, multi_res=multi_res)


    def track_list(self, station_id, action):
        self.list = self.stream_list(station_id, action, track_list=True)
    
        if self.list == None: return
        try:
            ch_list = [i['title'] for i in self.list]
            
            if len(self.list) > 1:
                ch_id = __dialog__.select(__lang__(32008).encode('utf-8'), ch_list)
                if ch_id == -1: return
            else: ch_id = 0
            ch_id = str(ch_id + 1)

            query = urlparse.urljoin(onlinestream_url, '/tracklist-xml.cgi?id=%s&ch=%s' % (station_id, ch_id))
            r = client.request(query, headers=headers)

            result = client.parseDOM(r, 'onlinestream.live')[0]

            title = client.parseDOM(result, 'title')[0]
            title = client.replaceHTMLCodes(title).encode('utf-8')

            tracklist = client.parseDOM(result, 'track')[:100]
            tr = []
            for track in tracklist:
                try:
                    time = client.parseDOM(track, 'time')[0].encode('utf-8')

                    song = client.parseDOM(track, 'song')[0]
                    if (song == '' or song == '-' or song == '?'): raise Exception()
                    song = client.replaceHTMLCodes(song).replace("&apos;", "'").encode('utf-8')
                    
                    label = '[B][COLOR white]%s[/COLOR][/B]  %s' % (time, song)
                    tr.append(label)
                except:
                    pass

            if tr == []:
                raise Exception()

            __dialog__.select(title, tr)
            return
        except:
            __dialog__.notification(title, __lang__(32010).encode('utf-8'), __addonicon__, 3000, sound=False)
            return


    def search(self, action):
        try:
            xbmc.executebuiltin('Dialog.Close(busydialog)')

            t = __lang__(32004).encode('utf-8')
            k = xbmc.Keyboard('', t) ; k.doModal()
            q = k.getText() if k.isConfirmed() else None

            if (q == None or q == '' or len(q) < 2): raise Exception()

            url = '%s?action=%s_list&search_text=%s' % (sys.argv[0], action, urllib.quote_plus(q))
            xbmc.executebuiltin('Container.Update(%s)' % url)
        except:
            return

    
    def get_xml(self, action):
        try:
            query = urlparse.urljoin(onlinestream_url, '/list.xml')
            xml = client.request(query, headers=headers)
            stations = client.parseDOM(xml, 'station')
            dom = '0' if action == 'radio' else '1'
            stations = [i for i in stations if client.parseDOM(i, 'tv')[0] == dom]
        except:
            stations = []
        return stations


    def get_tv_seq(self):
        try:
            r = client.request(urlparse.urljoin(onlinestream_url, '/tv-seq.xml'), headers=headers)
            tv_seq = client.parseDOM(r, 'station_id')
        except:
            tv_seq = []
        return tv_seq
