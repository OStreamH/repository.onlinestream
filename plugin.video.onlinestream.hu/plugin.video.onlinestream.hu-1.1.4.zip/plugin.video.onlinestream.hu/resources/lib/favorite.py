# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

import xbmc,os,xbmcvfs,xbmcaddon,xbmcgui

addonInfo = xbmcaddon.Addon().getAddonInfo
dataPath = xbmc.translatePath(addonInfo('profile')).decode('utf-8')
favoritesFile = os.path.join(dataPath, 'fav.db')
dialog = xbmcgui.Dialog()
lang = xbmcaddon.Addon().getLocalizedString


def getFavorites(id=False):
    try:
        dbcon = database.connect(favoritesFile)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM favorite")
        items = dbcur.fetchall()
        if not id == False:
            items = [i[0].encode('utf-8') for i in items]
    except:
        items = []

    return items


def addFavorite(id, name, type, image):
    try:    
        xbmcvfs.mkdir(dataPath)
        dbcon = database.connect(favoritesFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS favorite (""id TEXT, ""name TEXT, ""type TEXT, ""image TEXT, ""UNIQUE(id)"");")
        dbcur.execute("DELETE FROM favorite WHERE id = '%s'" %  id.decode('utf-8'))
        dbcur.execute("INSERT INTO favorite Values (?, ?, ?, ?)", (id.decode('utf-8'), name.decode('utf-8'), type.decode('utf-8'), image.decode('utf-8')))
        dbcon.commit()

        dialog.notification(name, lang(32020).encode('utf-8'), image, 3000, sound=False)
    except:
        return


def deleteFavorite(id):
    try:
        try:
            dbcon = database.connect(favoritesFile)
            dbcur = dbcon.cursor()
            dbcur.execute("DELETE FROM favorite WHERE id = '%s'" % id.decode('utf-8'))
            dbcon.commit()
        except:
            pass

        xbmc.executebuiltin('Container.Refresh')
    except:
        return


def clear():
    try:
        dbcon = database.connect(favoritesFile)
        dbcur = dbcon.cursor()
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        dbcur.execute("DROP TABLE IF EXISTS favorite")
        dbcur.execute("VACUUM")
        dbcon.commit()
    except:
        pass