# -*- coding: utf-8 -*-

'''
    Online Stream Addon for Kodi
    Copyright (C) 2017 aky01
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys,urllib,re,xbmcaddon,xbmcgui,xbmc,os,json

from resources.lib import client
from resources.lib import cache
from resources.lib import directory
from resources.lib import favorite
from resources.lib import m3u8_parser

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__addonicon__ = __addon__.getAddonInfo('icon')
__lang__ = xbmcaddon.Addon().getLocalizedString
__dialog__ = xbmcgui.Dialog()

class indexer:
    def __init__(self):
        self.list = []
        self.base_link = 'https://onlinestream.live'


    def resolve(self, url, image, title, mediatype, multi_res, stream_name = None):
        if mediatype == 'Music':
            try: url = client.request(url, geturl=True)
            except: pass

        pattern = 'KD86eW91dHViZVwuY29tXC9cUyooPzooPzpcL2UoPzptYmVkKSk/XC98d2F0Y2hcPyg/OlxTKj8mP3ZcPSkpfHlvdXR1XC5iZVwvKShbYS16QS1aMC05Xy1dezYsMTF9KQ=='.decode('base64')
        yt_link = re.search(pattern, url)
        if yt_link:
            url = 'plugin://plugin.video.youtube/play/?video_id=%s' % yt_link.group(1)

        item = xbmcgui.ListItem()
        stream_description = []
        if stream_name is not None:
            stream_description.append(stream_name)

        if not yt_link and multi_res == True:
            r = client.request(url)
            query = re.search("(https?.+?m3u8)", r)
            if query:
                query = query.group(1)
                try:
                    r = client.request(query)
                    sources = m3u8_parser.parse(r)['playlists']
                    #sources = re.findall('RESOLUTION\s*=\s*(\d+x\d+).+\n\s*(.*\.m3u8)', r)
                    available_resoulutions = list([i['stream_info']['resolution'] for i in sources])
                    RE_RESOLUTION_STRING = re.compile(r'(\d+) ?x ?(\d+)')
                    if len(sources) > 1:
                        preferred_video_quality = xbmcaddon.Addon().getSetting('preferred_video_quality')
                        q = None
                        if preferred_video_quality == '1': # auto-pick best available
                            try:
                                sorted_resoultions = []
                                for i in range(len(available_resoulutions)):
                                    sorted_resoultions.append((int(RE_RESOLUTION_STRING.match(available_resoulutions[i]).group(1)), i))
                                sorted_resoultions.sort()
                                _, q = sorted_resoultions[-1]
                            except: pass
                        if q is None:
                            q = __dialog__.select(__lang__(32013).encode('utf-8'), available_resoulutions)
                        if q == -1: return
                    else: q = 0
                    try:
                        res_with, res_height, RE_RESOLUTION_STRING.match(available_resoulutions[i]).groups()
                        item.addStreamInfo('video', {
                            'width': res_with,
                            'height': res_height
                        })
                    except: pass
                    url = query.rsplit('/', 1)[0] + '/' + sources[q]['uri']
                    stream_description.append(available_resoulutions[q])
                except:
                    url = query

        stream_description.append('[B]URL:[/B] {}'.format(url))
    
        item.setPath(url)
        item.setArt({'icon': image, 'thumb': image})
        item.setInfo(type=mediatype, infoLabels={'Title': title, 'Plot': '\n\n'.join(stream_description)})
        xbmc.Player().play(url, item)


    def favorites(self):
        try:
            fav_list = favorite.getFavorites()
            if fav_list == []: raise Exception()
            
            for id, title, type, image in fav_list:
                id = id.encode('utf-8')
                title = title.encode('utf-8')
                type = type.encode('utf-8')
    
                cm = [{'title': __lang__(32009).encode('utf-8'), 'query': {'action': '%s_track_list' % type, 'station_id': id}},
                    {'title': __lang__(32018).encode('utf-8'), 'query': {'action': 'favorite_delete', 'station_id': id}}]
                label = __lang__(32014).encode('utf-8') if type == 'tv' else __lang__(32015).encode('utf-8')
                self.list.append({'action': '%s_stream_list' % type, 'label': '%s  (%s)' % (title, label), 'image': image, 'station_id': id, 'cm': cm}) 
    
            directory.add(self.list, content='addons', isFolder=False)
        except:
            __dialog__.notification(__addonname__, __lang__(32019).encode('utf-8'), __addonicon__, 3000, sound=False)
            return


    def get_stations(self, action, station_id=None):
        stations = cache.get(self.get_json_data, 1, '/list.json', table='stations')
        if not stations:
            cache.clear(table='stations')
            __dialog__.notification(__addonname__, __lang__(32011).encode('utf-8'), __addonicon__, 3000, sound=False)
            return []

        stations = stations['stations']

        if station_id:
            return [i['station'][0] for i in stations if i['station'][0]['station_id'] == station_id][0]

        tv = '0' if action == 'radio' else '1'
        stations = [i['station'][0] for i in stations if i['station'][0]['tv'] == tv]

        if action == 'tv':
            filter = []
            tv_seq = cache.get(self.get_json_data, 1, '/tv-seq.json', table='tv_seq')
            if tv_seq:
                for i in tv_seq['stations']:
                    for x in stations:
                        if i['station_id'] == x['station_id']:
                            filter.append(x)
            else:
                cache.clear(table='tv_seq')
            filter += [i for i in stations if not i in filter]
            stations = [i for i in filter if not all('' == s['stream_url'].strip() for s in i['channel']) or not all('' == x['hls_url'].strip() for x in i['channel'])]

        return stations


    def station_list(self, action, search_text=None):
        stations = self.get_stations(action)
        fav_ids = favorite.getFavorites(id=True)

        for item in stations:
            try:
                title = item['title']
                title = client.replaceHTMLCodes(title).replace("&apos;", "'").encode('utf-8')

                station_id = item['station_id'].encode('utf-8')

                logo = item['logo'].encode('utf-8')
                if logo == None or logo.strip() == '': logo = os.path.join(__addon__.getAddonInfo('path'), 'resources', 'media', '%s.png' % action)
                
                if action == 'radio':
                    description = item['description']
                    description = client.replaceHTMLCodes(description).replace("&apos;", "'").encode('utf-8')
    
                    listeners = item['listeners'].encode('utf-8')
                    listeners = listeners if listeners.isdigit() and int(listeners) >= 0 else ''
                    
                    listeners_peak = item['listeners_peak'].encode('utf-8')
                    
                    broadcast = item['broadcast'].encode('utf-8')
                    broadcast = 'DAB+/FM' if broadcast == '1' else ''
                    
                    station_title = '[COLOR white][B]%s[/B][/COLOR]' % title
                    if not broadcast == '': station_title += '  [COLOR FF008000]%s[/COLOR]' % broadcast
                    if not listeners == '': station_title += '  [%s/%s]' % (listeners, listeners_peak)
                else: 
                    station_title = title
                
                cm = [{'title': __lang__(32009).encode('utf-8'), 'query': {'action': '%s_track_list' % action, 'station_id': station_id}}]
                if not station_id in fav_ids:
                    cm.append({'title': __lang__(32017).encode('utf-8'), 'query': {'action': 'favorite_add', 'station_id': station_id, 'title': title, 'type': action, 'image': logo}})

                self.list.append({'title': title, 'label': station_title, 'image': logo, 'station_id': station_id, 'cm': cm})

            except:
                pass
        
        
        if not search_text == None:
            self.list = [i for i in self.list if search_text.lower() in i['title'].lower()]
            if self.list == []:
                __dialog__.notification(__addonname__, __lang__(32012).encode('utf-8'), __addonicon__, 3000, sound=False)
                return

        if self.list == []: return
        for i in self.list: i.update({'action': '%s_stream_list' % action})
        
        infotype = 'Music' if action == 'radio' else 'Video'
        directory.add(self.list, content='addons', infotype=infotype, isFolder=False)


    def stream_list(self, station_id, action, image='', track_list=False):
        station = self.get_stations(action, station_id=station_id)

        station_title = station['title'].encode('utf-8')

        for item in station['channel']:
            try:
                stream_url = item['stream_url'].encode('utf-8')
                hls_url = item['hls_url'].encode('utf-8')
                if stream_url.strip() == '' and hls_url.strip() == '': continue
                
                channel_id = item['channel_id'].encode('utf-8')
                
                description = item['description']
                description = client.replaceHTMLCodes(description).replace("&apos;", "'").encode('utf-8')
                
                format = item['format'].encode('utf-8')
                
                channel_title = item['title'].encode('utf-8')
                
                listeners = item['listeners'].encode('utf-8')
                listeners = listeners if listeners.isdigit() and int(listeners) >= 0 else '?'
                
                listeners_peak = item['listeners_peak'].encode('utf-8')
                
                bitrate = item['bitrate'].encode('utf-8')
                
                resolution = item['video_resolution']

                if action == 'radio':
                    mediatype = 'Music' if not format.strip().lower() in ['flv', 'hls'] else 'Video'
                    title = '%s: %s [%s/%s] [%s, %s kbps]' % (channel_id, channel_title, listeners, listeners_peak, format, bitrate)
                    title = re.sub('\[\?\/.*\]\s', '', title)
                    if re.search(',\s+\D', title):
                        title = re.sub('\s*kbps', '', title)
                    litle = title.replace('[?, ', '[').replace('[, ', '[')
                    title = re.sub(',\s*\?', '', title)
                    title = re.sub('\[\s*\??\s*\]', '', title)

                else:
                    mediatype = 'Video'
                    title = 'Stream %s - %s' % (channel_id, description) if not description == '' else 'Stream %s' % channel_id

                self.list.append({'station_title': station_title, 'title': title, 'stream_url': stream_url, 'hls_url': hls_url, 'video_resolution': resolution, 'mediatype': mediatype})
            except:
                pass

        if self.list == []: return

        if not track_list == False:
            return self.list

        ch_list = [i['title'] for i in self.list]

        if len(self.list) == 1 or xbmcaddon.Addon().getSetting('preferred_stream') == '1': # auto-select first available stream
            q = 0
        else:
            q = __dialog__.select(__lang__(32008).encode('utf-8'), ch_list)
            if q == -1: return

        mediatype = self.list[q]['mediatype']
        url = self.list[q]['hls_url'] if mediatype == 'Video' and self.list[q]['hls_url'].strip() != '' else self.list[q]['stream_url']
        multi_res = True if u'T\xf6bbf\xe9le' in self.list[q]['video_resolution'] else False
        title = self.list[q]['station_title']
        self.resolve(url, image, title=title, mediatype=mediatype, multi_res=multi_res, stream_name=ch_list[q])


    def track_list(self, station_id, action):
        self.list = self.stream_list(station_id, action, track_list=True)
    
        if self.list == None: return
        try:
            ch_list = [i['title'] for i in self.list]

            if len(self.list) == 1 or xbmcaddon.Addon().getSetting('preferred_stream') == '1': # auto-select first available stream
                ch_id = 0
            else:
                ch_id = __dialog__.select(__lang__(32008).encode('utf-8'), ch_list)
                if ch_id == -1: return

            ch_title = ch_list[ch_id]

            data = self.get_json_data('/tracklist-json.cgi?id=%s&ch=%s' % (station_id, str(ch_id + 1)))

            title = data['station'][0]['title']
            title = client.replaceHTMLCodes(title).encode('utf-8')

            tracklist = data['tracklist'][:100]
            tr = []
            for track in tracklist:
                try:
                    time = track['track']['time']
                    song = track['track']['song']
                    if (song == '' or song == '-' or song == '?'): raise Exception()
                    song = client.replaceHTMLCodes(song).replace("&apos;", "'")
                    
                    label = u'[B][COLOR white]%s[/COLOR][/B]  %s' % (time, song)
                    tr.append(label.encode('utf-8'))
                except:
                    pass

            if tr == []:
                raise Exception()

            __dialog__.select(title, tr)
            return
        except:
            __dialog__.notification(ch_title, __lang__(32010).encode('utf-8'), __addonicon__, 3000, sound=False)
            return


    def search(self, action):
        xbmc.executebuiltin('Dialog.Close(busydialog)')

        t = __lang__(32004).encode('utf-8')
        k = xbmc.Keyboard('', t) ; k.doModal()
        q = k.getText() if k.isConfirmed() else None

        if (q == None or q == '' or len(q) < 2):
            return

        url = '%s?action=%s_list&search_text=%s' % (sys.argv[0], action, urllib.quote_plus(q))
        xbmc.executebuiltin('Container.Update(%s)' % url)


    def get_json_data(self, url):
        try:
            r = client.request(self.base_link + url)
            data = json.loads(r)
        except:
            data = []
        return data
